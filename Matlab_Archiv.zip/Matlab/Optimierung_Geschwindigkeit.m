% Kraftstoffverbrauch x = km/h
y = a?(x-40)2 + b 
p = [1 0 -6 4];
polyval(p,1)
roots(p)

syms x
p = x^3-6*x+4;
solve(p)
%f = x^p - a gegeben
x = 1; % Start
a = 2; % Zu berechnende Zahl
p = 3; % Wurzel
n = 10; % Anzahl Durchl�ufe
res = C4_NewtonWurzel(a,p,x,n)

